# Security Policy

## Reporting a Vulnerability

Vulnerabilities can be reported via email or twitter.
Mail: owbypass@gmail.com
Twitter: @znixbtw
